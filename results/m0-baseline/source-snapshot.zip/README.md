# CUDA GEMM Lab

本轮按 [任务书](GEMM_PROJECT_BRIEF.md) 的 M0 建立工程基础，**naive GEMM 由你实现**。当前可运行 FP32 cuBLAS 基线、CPU double 验证、CUDA Event benchmark 和 profile 模式；不包含 shared/register/WMMA。实际结果见 [REPORT.md](REPORT.md)。

## 构建与运行

已在 Windows、RTX 4060 Laptop（SM 8.9）、MSVC 19.44、CUDA Toolkit 13.2 上验证。需要 CMake 3.24+、MSVC x64 工具和支持目标架构的 CUDA Toolkit；Python 仅用于额外 CLI 测试。CUDA DLL 所在目录需在 PATH 中。

在项目根目录运行：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\build.ps1
.\build\gemm.exe --mode info
.\build\gemm.exe --mode check --kernel cublas
ctest --test-dir build --output-on-failure
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\benchmark.ps1 -Kernel cublas
```

脚本仅为子进程启用脚本执行，不更改系统执行策略；自动加载 MSVC 环境，使用 NMake 和 Release。另一张 GPU 可用 `-Architecture 86` 等覆盖目标。若已经在 x64 Native Tools 终端中，也可直接：

```powershell
cmake -S . -B build -G "NMake Makefiles" -DCMAKE_BUILD_TYPE=Release -DCMAKE_CUDA_ARCHITECTURES=89
cmake --build build --config Release
```

输出为 `build/gemm.exe`。保留 `-lineinfo` 和 ptxas 资源报告，不使用 `-G` 或 `--use_fast_math`。`-DBUILD_TESTING=OFF` 可关闭测试目标。

## 接入你自己的 naive

只需编辑 [src/naive.cu](src/naive.cu)，接口在 [src/naive.cuh](src/naive.cuh)。当前文件没有 GEMM 实现，调用 `--kernel naive` 会非零退出。

1. 添加你自己的 CUDA kernel，建议符号名以 `sgemm_` 开头，便于 NCU 过滤。
2. 在 `launch_naive` 中用传入的 stream 启动它，返回 launch 状态；不要分配、复制或同步。每个输出都要写入，包括尾部，地址计算使用足够宽的整数。
3. 将 `naive_available()` 改为返回 `true`，重新构建。
4. 先通过正确性和 sanitizer，再运行性能矩阵：

```powershell
.\build\gemm.exe --mode check --kernel naive
.\build\gemm.exe --mode check --kernel naive --m 65 --n 97 --k 33 --seed 42
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\benchmark.ps1 -Kernel naive
```

同一入口将自动比较 naive 和 cuBLAS 的所有输出，并单独用 CPU double 全量或抽样复核两者；benchmark 自动输出两行和 `t_cublas/t_self`，交替测量两者。代码接线已完成，这条双实现 GPU 路径仍待你提供 naive 后实际验证。

## 契约与 CLI

`C[M,N] = A[M,K] * B[K,N]`，连续 row-major、无转置，FP32 输入/累加/输出，固定 `alpha=1,beta=0`。正整数尺寸，缓冲区互不重叠。当前数值验收范围 `K <= 4096`；更大 K 明确报错，需先修订数值契约。尺寸/字节数使用溢出检查，分配前检查可用显存。

| 模式 | 参数和行为 |
|---|---|
| `info` | 默认模式；设备 0、资源限制、Runtime/Driver API 版本、cuBLAS、编译器、架构、源码 SHA256 |
| `check` | 无尺寸时跑 32 个固定用例；或同时指定 M/N/K 跑一个 seed 固定的随机输入 |
| `bench` | 要求 M/N/K；验证通过后预热和计时；`--kernel cublas` 仅输出一个基线结果 |
| `profile` | 要求 M/N/K；默认 20 次预热 + 1 次目标调用，一轮；不计算参考、不验证、不输出性能排名 |

公共参数：`--mode --kernel --dtype --m --n --k --seed`。计时参数：`--warmup --iters --rounds`。普通 bench 默认 20/100/5，批量脚本读取矩阵 CSV 内校准后的次数。`--csv NEW_FILE` 仅用于 bench，不覆盖已有结果。profile 仅允许 `--rounds 1`。未知参数、重复参数、部分尺寸、未实现 kernel/dtype 均报错。返回码 0=成功、2=数值不通过、1=参数/CUDA/cuBLAS/文件错误。

```powershell
.\build\gemm.exe --mode bench --kernel cublas --m 2048 --n 2048 --k 2048 --warmup 20 --iters 44 --rounds 5 --seed 42 --csv results\one-new-run.csv
```

## 固定 benchmark 矩阵

唯一批量配置是 [benchmarks/matrix.csv](benchmarks/matrix.csv)，定义和锁定规则见 [benchmarks/README.md](benchmarks/README.md)。

| ID | M | N | K | iters | 用途 |
|---|---:|---:|---:|---:|---|
| P1 | 2048 | 2048 | 2048 | 44 | 规则吞吐与复用 |
| P2 | 16 | 4096 | 4096 | 335 | 小 M、并行供给与 tile 浪费 |
| P3 | 1001 | 769 | 513 | 800 | 非整 tile 尾部 |

统一 FP32、seed=42、warmup=20、rounds=5。脚本把矩阵、精确命令、各轮均值、校验误差、计时统计、环境、运行前后 GPU 状态、源码/可执行文件哈希存到新的 `results/run-*` 目录。也可指定新的 `-OutputDir results\my-run`。`-Iters N` 可以覆盖三组重复次数，实际值始终写入 CSV；同一组中的自写实现和 cuBLAS 必须使用相同次数。

## 验证与计时定义

输入生成器 `mt19937_u24_v1`：`std::mt19937(seed)` 连续生成 A 再生成 B；取每个输出的高 24 位，乘 `2^-23` 再减 1，得到精确可表示的 FP32 `[-1,1)` 输入。没有依赖 STL 的 `uniform_real_distribution` 映射。无需保存大型 A/B 二进制数据即可复现。

固定正确性 shape 为 `(1,1,1)`、`(2,2,3)`、`(17,19,23)`、`(65,97,33)`、`(15,16,17)`、`(16,17,16)`、`(33,31,32)`、`(17,17,17)`；每个 shape 跑随机、零 A、单位/矩形单位 A、小整数四种输入。另有 `(31,37,29)` 独立边界测试。新增 tile 后再增加其附近的少量正确性用例，性能集合保持不变。

当 `M*N <= 65536` 且 `M*N*K <= 8,000,000` 时用 CPU double 全量参考；否则固定检查边角、内部行列交点以及 17 个线性等距位置，去重后取样。本轮 P1/P2/P3 分别检查 51/46/50 个 CPU 点积，**cuBLAS 不与自身比较**。自写实现同时全量比较 cuBLAS。

先将 C 的全部字节设为 `0xff`（FP32 NaN）检测漏写；全部输出均检查有限性。误差标准为 `abs(error) <= 1e-3 + 1e-4*abs(reference)`。相对 Frobenius 误差分母为 `max(||reference||_F,1e-30)`；CSV 的 `reference_scope/cpu_scope` 明确区分全量与抽样，抽样范数不代表整矩阵范数。失败用例不会计时，数值失败 CSV 写 `invalid`，时间和加速比写 `NA`。

cuBLAS 使用 `cublasGemmEx`、FP32 A/B/C、`CUBLAS_COMPUTE_32F_PEDANTIC`，handle 设置 `CUBLAS_PEDANTIC_MATH`、host 标量以及同一 stream。row-major 映射为 `C^T=B^T*A^T`：`m=N,n=M,k=K`，先 B/ld=N，再 A/ld=K，C/ld=N，两个 op 均为 N。API 语义参照 [NVIDIA cuBLAS 文档](https://docs.nvidia.com/cuda/cublas/index.html)，本地安装头文件版本 13.4.0。

每轮同 stream 记录 start Event，执行 R 次 GEMM，记录 stop，等待并除以 R。分配、拷贝、初始化、handle、参考和检查都在区间外。汇报 5 个轮均值的中位数和 min/max，不是 p95。`GFLOP/s=2MNK/(10^6*t_ms)`；比值为 `t_cublas/t_self`，cuBLAS 自身的 1 不表示自写实现达到库性能。稳态重复使用同一工作集；主机提交间隙也可能进入 Event 区间。

## Profiling 与 Sanitizer

本机工具对原始临时路径出现过异常；指定项目中的 ASCII 临时目录后 NSYS 成功。以下仅影响当前终端进程环境。工具目录随安装版本调整。

```powershell
New-Item -ItemType Directory -Force build\profiler-temp | Out-Null
$env:TEMP = (Resolve-Path build\profiler-temp).Path
$env:TMP = $env:TEMP
$env:NV_COMPUTE_PROFILER_DISABLE_STOCK_FILE_DEPLOYMENT = '1'
$ncuRoot = 'C:\Program Files\NVIDIA Corporation\Nsight Compute 2026.1.1'
$nsys = 'C:\Program Files\NVIDIA Corporation\Nsight Systems 2025.6.3\target-windows-x64\nsys.exe'

# 当前可运行的工具冒烟测试；不要覆盖已有报告。
.\build\gemm.exe --mode check --kernel cublas --m 2048 --n 2048 --k 2048 --seed 42
& $nsys profile --trace=cuda,cublas --sample=none --cpuctxsw=none --output=results\new-cublas-nsys .\build\gemm.exe --mode profile --kernel cublas --m 2048 --n 2048 --k 2048 --warmup 20 --iters 1 --seed 42
& $nsys stats --report cuda_gpu_kern_sum,cuda_api_sum results\new-cublas-nsys.nsys-rep
& "$ncuRoot\target\windows-desktop-win7-x64\ncu.exe" --config-file off --section-folder "$ncuRoot\sections" --section LaunchStats --kernel-name 'regex:.*sgemm.*' --launch-skip 20 --launch-count 1 --export results\new-cublas-ncu .\build\gemm.exe --mode profile --kernel cublas --m 2048 --n 2048 --k 2048 --warmup 20 --iters 1 --seed 42
```

本机 NCU 目前返回 `ERR_NVGPUCTRPERM`，没有硬件计数器报告。说明见 [NVIDIA 权限文档](https://developer.nvidia.com/ERR_NVGPUCTRPERM)；本轮未更改驱动权限设置。NCU 的 section/过滤规则以本地 `--help`、`--list-sections` 为准。

你实现 naive 后，先单独 check 同一 shape/seed，再把采集目标改成 `--kernel naive`，NCU filter 改为 `'regex:^sgemm_'`（以实际 kernel 名称为准）。每次操作一个匹配 kernel 时，`--launch-skip 20 --launch-count 1` 采集预热后的第一个 launch。

```powershell
# 实现 naive 后执行；当前会明确报未实现。
foreach ($tool in @('memcheck','racecheck','synccheck')) {
    compute-sanitizer --tool $tool --error-exitcode 3 .\build\gemm.exe --mode check --kernel naive --m 65 --n 97 --k 33 --seed 42
}
```

## 代码入口

| 文件 | 内容 |
|---|---|
| [src/gemm.cu](src/gemm.cu) | CLI、资源释放、数据生成、参考/验证、库映射、Event 计时、CSV |
| [src/naive.cu](src/naive.cu) | 你自己的 naive 实现位置，当前只有不可用接口 |
| [CMakeLists.txt](CMakeLists.txt) | 架构、Release、cuBLAS 链接、源码摘要、CTest |
| [tests/harness_tests.cu](tests/harness_tests.cu) | 已知手算矩阵、错误结果、NaN/Inf、溢出和计时统计检测 |
| [tests/cli_tests.py](tests/cli_tests.py) | 参数、独立参考、CSV 防覆盖、profile 隔离的集成测试 |
| [scripts/benchmark.ps1](scripts/benchmark.ps1) | 读取固定矩阵、收集每次运行的证据 |

当前目录未初始化 git；CMake 将关键文件内容摘要编入程序，实际运行保留 SHA256 清单和源码快照。后续使用 git 后，可再将结果与 commit 关联。
