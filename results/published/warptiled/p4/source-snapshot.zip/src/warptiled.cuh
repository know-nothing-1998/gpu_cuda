#pragma once
#include <cuda_runtime.h>

bool warptiled_available() noexcept;

// A[M,K], B[K,N], C[M,N]: contiguous row-major FP32; alpha=1, beta=0.
// Enqueue on stream, overwrite C, and return launch status. No allocations or sync.
cudaError_t launch_warptiled(const float* a, const float* b, float* c,
                           int m, int n, int k, cudaStream_t stream);

template <int BM, int BN, int BK, int WM, int WN, int TM, int TN, int WNITER>
cudaError_t launch_warptiled_config(const float* a, const float* b, float* c, int m, int n, int k,
                                   cudaStream_t stream);

template <int BM, int BN, int BK, int WM, int WN, int TM, int TN, int WNITER>
__global__ void sgemm_warptiled(const float* a, const float* b, float* c, int m, int n, int k);
