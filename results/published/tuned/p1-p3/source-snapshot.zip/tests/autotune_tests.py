"""CPU-only contracts for accepting and ranking autotuning measurements."""

import copy
import csv
import importlib.util
import json
from pathlib import Path
import statistics
import sys
import tempfile
import unittest


ROOT = Path(__file__).resolve().parent.parent
SPEC = importlib.util.spec_from_file_location(
    "gemm_autotune_under_test", ROOT / "scripts" / "autotune.py"
)
autotune = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = autotune
SPEC.loader.exec_module(autotune)

SOURCE_HASH = "a" * 64
SHAPE = {
    "id": "P1", "m": 2048, "n": 2048, "k": 2048,
    "seed": 42, "warmup": 100, "iters": 44, "rounds": 3,
}
# The complete CSV schema emitted by src/gemm.cu.
CSV_FIELDS = (
    "requested_kernel,actual_kernel,m,n,k,input_dtype,accum_dtype,output_dtype,"
    "seed,generator,status,reference_scope,compared,max_abs,relative_frob,"
    "failed,nonfinite,cpu_scope,cpu_compared,cpu_max_abs,cpu_relative_frob,"
    "cpu_failed,warmup,iters,rounds,median_ms,min_ms,max_ms,gflops,"
    "cublas_over_self,round_mean_ms,source_sha256,build_type,cuda_architectures,"
    "gpu,cuda_runtime,cuda_driver,cublas_version,math_mode,compute_type"
).split(",")


def benchmark_rows():
    rows = []
    for kernel, samples in (("tuned", [2.0, 3.0, 4.0]), ("cublas", [1.0, 1.5, 2.0])):
        row = dict.fromkeys(CSV_FIELDS, "0")
        row.update(
            requested_kernel="tuned", actual_kernel=kernel,
            input_dtype="fp32", accum_dtype="fp32", output_dtype="fp32",
            generator="mt19937_u24_v1", status="valid",
            reference_scope="cublas_full" if kernel == "tuned" else "cpu_sampled",
            compared=str(SHAPE["m"] * SHAPE["n"]),
            cpu_scope="sampled", cpu_compared="1024",
            median_ms=str(statistics.median(samples)),
            min_ms=str(min(samples)), max_ms=str(max(samples)),
            round_mean_ms=";".join(map(str, samples)), source_sha256=SOURCE_HASH,
            build_type="Release", cuda_architectures="89",
            gpu="NVIDIA GeForce RTX 4060 Laptop GPU",
            cuda_runtime="13020", cuda_driver="13020", cublas_version="130200",
            compute_type="CUBLAS_COMPUTE_32F_PEDANTIC",
        )
        row.update({key: str(value) for key, value in SHAPE.items() if key != "id"})
        rows.append(row)
    return rows


class BenchmarkCsvTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory(prefix="gemm-autotune-test-")
        self.addCleanup(temporary.cleanup)
        self.path = Path(temporary.name) / "benchmark.csv"

    def read(self, rows):
        with self.path.open("w", encoding="utf-8-sig", newline="") as output:
            writer = csv.DictWriter(output, fieldnames=CSV_FIELDS)
            writer.writeheader()
            writer.writerows(rows)
        return autotune.read_benchmark(
            self.path, SHAPE, SOURCE_HASH,
            SHAPE["warmup"], SHAPE["iters"], SHAPE["rounds"],
        )

    def test_accepts_actual_two_row_format_and_either_row_order(self):
        for rows in (benchmark_rows(), list(reversed(benchmark_rows()))):
            with self.subTest(first=rows[0]["actual_kernel"]):
                parsed = self.read(rows)
                self.assertEqual(set(parsed), {"tuned", "cublas"})
                self.assertEqual(parsed["tuned"]["samples_ms"], [2.0, 3.0, 4.0])
                self.assertEqual(parsed["tuned"]["median_ms"], 3.0)
                self.assertEqual(parsed["cublas"]["median_ms"], 1.5)

    def test_rejects_numerical_failure_in_either_row(self):
        for index in (0, 1):
            for field, value in (
                ("status", "invalid"), ("status", "failed"),
                ("failed", "1"), ("nonfinite", "1"), ("cpu_failed", "1"),
            ):
                with self.subTest(row=index, field=field, value=value):
                    rows = benchmark_rows()
                    rows[index][field] = value
                    with self.assertRaises(ValueError):
                        self.read(rows)

    def test_requires_full_cublas_comparison_and_nonempty_cpu_checks(self):
        invalid = (
            (0, "reference_scope", "sampled"),
            (0, "compared", "0"),
            (0, "compared", str(SHAPE["m"] * SHAPE["n"] - 1)),
            (0, "cpu_compared", "0"),
            (1, "cpu_compared", "0"),
        )
        for index, field, value in invalid:
            with self.subTest(row=index, field=field, value=value):
                rows = benchmark_rows()
                rows[index][field] = value
                with self.assertRaises(ValueError):
                    self.read(rows)

    def test_rejects_stale_source_or_incompatible_build_and_precision(self):
        for index in (0, 1):
            for field, value in (
                ("source_sha256", "b" * 64), ("build_type", "Debug"),
                ("requested_kernel", "register"),
                ("compute_type", "CUBLAS_COMPUTE_32F_FAST_TF32"),
                ("input_dtype", "fp16"), ("accum_dtype", "fp16"),
                ("output_dtype", "fp16"),
            ):
                with self.subTest(row=index, field=field):
                    rows = benchmark_rows()
                    rows[index][field] = value
                    with self.assertRaises(ValueError):
                        self.read(rows)

    def test_rejects_different_shape_seed_or_measurement_settings(self):
        for index in (0, 1):
            for field in ("m", "n", "k", "seed", "warmup", "iters", "rounds"):
                with self.subTest(row=index, field=field):
                    rows = benchmark_rows()
                    rows[index][field] = str(SHAPE[field] + 1)
                    with self.assertRaises(ValueError):
                        self.read(rows)

    def test_rejects_nonfinite_zero_negative_or_incomplete_samples(self):
        for index in (0, 1):
            for samples in ("2;nan;4", "2;inf;4", "2;0;4", "2;-1;4", "2;3"):
                with self.subTest(row=index, samples=samples):
                    rows = benchmark_rows()
                    rows[index]["round_mean_ms"] = samples
                    with self.assertRaises(ValueError):
                        self.read(rows)

    def test_rejects_median_not_supported_by_samples(self):
        for median in ("nan", "0", "0.001"):
            with self.subTest(median=median):
                rows = benchmark_rows()
                rows[0]["median_ms"] = median
                with self.assertRaises(ValueError):
                    self.read(rows)

    def test_requires_exactly_one_tuned_and_one_cublas_row(self):
        rows = benchmark_rows()
        for malformed in (rows[:1], rows[1:], [rows[0], rows[0]], rows + [rows[1]]):
            with self.subTest(kernels=[row["actual_kernel"] for row in malformed]):
                with self.assertRaises(ValueError):
                    self.read(malformed)


BASELINE = autotune.Config(64, 64, 64, 4, 4)
CANDIDATE = autotune.Config(64, 64, 16, 4, 4)
OTHER = autotune.Config(16, 64, 16, 2, 4)


def measurement(config, pass_number, ms, phase="confirm", case="P1"):
    return {
        "config": config.name, "case": case, "phase": phase, "pass": pass_number,
        "source_sha256": SOURCE_HASH,
        "csv": f"{config.name}-{case}-{phase}-{pass_number}.csv",
        "timing": {
            "tuned": {"samples_ms": [ms, ms, ms], "median_ms": ms},
            "cublas": {"samples_ms": [0.5, 0.5, 0.5], "median_ms": 0.5},
        },
    }


class RankingTests(unittest.TestCase):
    def setUp(self):
        self.baseline_records = [
            measurement(BASELINE, 1, 2.0), measurement(BASELINE, 2, 2.2)
        ]

    def rank(self, records, configs=(BASELINE, CANDIDATE, OTHER)):
        return autotune.ranking_for(SHAPE, configs, records, BASELINE.name)

    def test_ranks_confirmation_only_and_keeps_shapes_separate(self):
        records = self.baseline_records + [
            measurement(CANDIDATE, 1, 1.0), measurement(CANDIDATE, 2, 1.2),
            measurement(BASELINE, 1, 0.0001, phase="screen"),
            measurement(OTHER, 1, 0.0001, phase="screen"),
            measurement(OTHER, 1, 0.0001, case="P2"),
            measurement(OTHER, 2, 0.0001, case="P2"),
        ]
        ranked = self.rank(records)
        self.assertEqual([item["config"] for item in ranked],
                         [CANDIDATE.name, BASELINE.name])
        self.assertAlmostEqual(ranked[0]["median_ms"], 1.1)
        self.assertAlmostEqual(ranked[0]["baseline_over_self"], 2.1 / 1.1)
        self.assertAlmostEqual(ranked[0]["gflops"], 2 * 2048**3 / (1.1 * 1e6))
        self.assertTrue(all("-confirm-" in path for path in ranked[0]["csv_files"]))

    def test_missing_or_duplicate_pass_cannot_win(self):
        incomplete_sets = (
            [measurement(CANDIDATE, 1, 0.0001)],
            [measurement(CANDIDATE, 1, 0.0001), measurement(CANDIDATE, 1, 0.0001)],
            [measurement(CANDIDATE, 1, 0.0001), measurement(CANDIDATE, 3, 0.0001)],
        )
        for incomplete in incomplete_sets:
            with self.subTest(passes=[record["pass"] for record in incomplete]):
                ranked = self.rank(self.baseline_records + incomplete)
                self.assertEqual([item["config"] for item in ranked], [BASELINE.name])

    def test_excluded_failed_config_cannot_reenter_from_retained_records(self):
        # execute() removes failed candidates from its eligible configuration list.
        # Their earlier measurements may still exist in the audit trail.
        records = self.baseline_records + [
            measurement(CANDIDATE, 1, 0.0001), measurement(CANDIDATE, 2, 0.0001)
        ]
        ranked = self.rank(records, configs=[BASELINE])
        self.assertEqual([item["config"] for item in ranked], [BASELINE.name])

    def test_baseline_needs_complete_confirmation_even_if_screening_succeeded(self):
        records = [
            measurement(BASELINE, 1, 2.0, phase="screen"),
            measurement(BASELINE, 1, 2.0),
            measurement(CANDIDATE, 1, 1.0), measurement(CANDIDATE, 2, 1.0),
        ]
        with self.assertRaisesRegex(ValueError, "baseline"):
            self.rank(records)


class SearchSpaceTests(unittest.TestCase):
    def test_asymmetric_block_and_reduction_tiles_are_supported(self):
        for config in (
            BASELINE, CANDIDATE, OTHER,
            autotune.Config(128, 64, 16, 8, 4),
            autotune.Config(64, 64, 16, 8, 2),
        ):
            with self.subTest(config=config):
                self.assertIsNone(autotune.reject_reason(config))
        self.assertEqual(OTHER.threads, 128)
        self.assertEqual(OTHER.shared_bytes, 5120)

    def test_rejects_invalid_types_divisibility_alignment_and_resource_usage(self):
        invalid = (
            autotune.Config(0, 64, 16, 4, 4),
            autotune.Config(64, 64, 16, 0, 4),
            autotune.Config(True, 64, 16, 1, 4),
            autotune.Config(64, 64, 16, 4.0, 4),
            autotune.Config(64, 64, 16, 3, 4),
            autotune.Config(64, 64, 6, 4, 4),
            autotune.Config(64, 66, 16, 4, 2),
            autotune.Config(64, 64, 16, 1, 1),
            autotune.Config(128, 128, 64, 8, 8),
        )
        for config in invalid:
            with self.subTest(config=config):
                self.assertIsNotNone(autotune.reject_reason(config))
        self.assertIsNotNone(autotune.reject_reason(BASELINE, max_threads=128))
        self.assertIsNotNone(autotune.reject_reason(BASELINE, max_shared=16384))
        self.assertIsNotNone(autotune.reject_reason(
            autotune.Config(128, 128, 64, 8, 8), max_shared=102400
        ))

    def test_load_space_preserves_baseline_deduplicates_and_reports_rejections(self):
        spec = {
            "baseline": [64, 64, 64, 4, 4],
            "block_tiles": [[64, 64], [16, 64], [64, 64]],
            "bk": [16, 64],
            "thread_tiles": [[4, 4], [3, 4]],
        }
        with tempfile.TemporaryDirectory(prefix="gemm-autotune-space-") as temporary:
            path = Path(temporary) / "space.json"
            path.write_text(json.dumps(spec), encoding="utf-8-sig")
            baseline, valid, rejected = autotune.load_space(path)
            self.assertEqual(baseline, BASELINE)
            self.assertEqual(valid[0], BASELINE)
            self.assertEqual(len(valid), len(set(valid)))
            self.assertIn(autotune.Config(16, 64, 16, 4, 4), valid)
            self.assertTrue(rejected)
            self.assertTrue(all(item["reason"] for item in rejected))

            invalid_spec = copy.deepcopy(spec)
            invalid_spec["baseline"] = [64, 64, 64, 0, 4]
            path.write_text(json.dumps(invalid_spec), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "baseline"):
                autotune.load_space(path)


if __name__ == "__main__":
    unittest.main()
