#include "kernel_registry.cuh"

#include "naive.cuh"
#include "coalesced.cuh"
#include "shared.cuh"
#include "register.cuh"
#include "tuned.cuh"

const std::vector<KernelEntry>& custom_kernels() {
    static const std::vector<KernelEntry> kernels{
        {"naive", "Uncoalesced baseline: thread x -> row, y -> column",
         "src/naive.cu", naive_available, launch_naive},
        {"coalesced", "Coalesced global-memory access: thread x -> column",
         "src/coalesced.cu", coalesced_available, launch_coalesced},
        {"shared", "Block tiling with shared-memory reuse",
         "src/shared.cu", shared_available, launch_shared},
        {"register", "Register tiling: multiple output values per thread",
         "src/register.cu", register_available, launch_register},
        {"tuned", "Further tile, vectorized-load, and scheduling experiments",
         "src/tuned.cu", tuned_available, launch_tuned},
    };
    return kernels;
}

const KernelEntry* find_custom_kernel(const std::string& name) {
    for (const auto& kernel : custom_kernels()) {
        if (name == kernel.name) return &kernel;
    }
    return nullptr;
}
