#include "register.cuh"

// TODO: Set true after implementing your register-tiled kernel below.
bool register_available() noexcept { return false; }

cudaError_t launch_register(const float* a, const float* b, float* c,
                            int m, int n, int k, cudaStream_t stream) {
    // TODO: Compute multiple C elements per thread with register accumulators.
    // Reuse loaded values and keep edge dimensions correct.
    // Replace this stub with the launch and return cudaGetLastError().
    (void)a; (void)b; (void)c;
    (void)m; (void)n; (void)k; (void)stream;
    return cudaErrorNotSupported;
}
