#pragma once
#include <cuda_runtime.h>

// User-owned extension point. No GEMM algorithm is supplied here.
bool naive_available() noexcept;

// A[M,K], B[K,N], C[M,N], contiguous row-major; alpha=1, beta=0.
// Buffers are valid, disjoint, device-resident; dimensions are positive.
// Enqueue on the supplied stream, overwrite every C element, do not synchronize.
// Use size_t for address arithmetic; return the CUDA launch status.
cudaError_t launch_naive(const float* a, const float* b, float* c,
                         int m, int n, int k, cudaStream_t stream);
