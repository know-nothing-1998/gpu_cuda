#include "naive.cuh"

// Implement your kernel in this file, then return true below.
bool naive_available() noexcept { return false; }

cudaError_t launch_naive(const float*, const float*, float*,
                         int, int, int, cudaStream_t) {
    // Deliberately unimplemented: never substitute cuBLAS for your kernel.
    return cudaErrorNotSupported;
}
